httpDataOnPremise = [
  ['HTTP throughput (requests/s)', 'pod ip', 'load balancer', 'on-premise (skupper)', 'cloud (load balancer)', 'cloud (route)', 'cloud (skupper)'],
  ['From on-premise to', 7256.49, 6257.3, 1040.28, 70.0012, 67.7586, 74.9024],
]
httpDataCloud = [
  ['HTTP throughput (requests/s)', 'pod ip', 'load balancer', 'on-premise (skupper)', 'cloud (load balancer)', 'cloud (route)', 'cloud (skupper)'],
  ['From cloud to', 13335.2, 11827.2, 74.6309, 11827.2, 4852.49, 2660.12],
]
httpOptionsOnPremise = {
  title: 'From On-Premise cluster',
  bar: {
    groupWidth: '100%'
  },
  legend: {
    position: 'bottom',
    textStyle: {
        fontSize: 14,
    }
  }
}
httpOptionsCloud = {
  title: 'From Cloud cluster',
  bar: {
    groupWidth: '100%'
  },
  legend: {
    position: 'bottom',
    textStyle: {
        fontSize: 14,
    }
  }
}
