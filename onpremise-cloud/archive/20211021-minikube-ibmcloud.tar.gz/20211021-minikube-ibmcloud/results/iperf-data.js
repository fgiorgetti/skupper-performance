iperfDataOnPremise = [
  ['IPERF throughput (gbps)', 'pod ip', 'load balancer', 'on-premise (skupper)', 'cloud (load balancer)', 'cloud (route)', 'cloud (skupper)'],
  ['From on-premise to', 23, 19.1, 3.39, 0.12, 0, 0.05],
]
iperfDataCloud = [
  ['IPERF throughput (gbps)', 'pod ip', 'load balancer', 'on-premise (skupper)', 'cloud (load balancer)', 'cloud (route)', 'cloud (skupper)'],
  ['From cloud to', 15, 15.6, 0.08, 15.6, 0, 3.97],
]
iperfOptionsOnPremise = {
  title: 'From On-Premise cluster',
  bar: {
    groupWidth: '100%'
  },
  legend: {
    position: 'bottom',
    textStyle: {
        fontSize: 14,
    }
  }
}
iperfOptionsCloud = {
  title: 'From Cloud cluster',
  bar: {
    groupWidth: '100%'
  },
  legend: {
    position: 'bottom',
    textStyle: {
        fontSize: 14,
    }
  }
}
