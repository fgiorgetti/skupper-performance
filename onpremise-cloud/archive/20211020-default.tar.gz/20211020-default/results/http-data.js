httpData = [
  ['HTTP throughput (requests/s)', 'pod ip', 'load balancer', 'on-premise (skupper)', 'cloud (load balancer)', 'cloud (route)', 'cloud (skupper)'],
  ['on-premise', 34255.3, 42459.7, 2823.16, 1243.89, 1222.34, 1287.7],
  ['cloud', 18308.6, 17564.4, 1266.72, 17564.4, 8958.27, 2261.98],
]

httpOptions = {
  title: 'Skupper - HTTP performance numbers',
  bar: {
    groupWidth: '100%'
  },
  chart: {
    title: 'Skupper - HTTP performance numbers',
    subtitle: 'On-premise / Cloud (HTTP adaptor)',
  }
}
