httpDataOnPremise = [
  ['HTTP throughput (requests/s)', 'cloud (k8s lb)', 'cloud (route)', 'cloud (skupper)'],
  ['From on-premise to', 1243.89, 1222.34, 1287.7],
]
httpDataCloud = [
  ['HTTP throughput (requests/s)', 'on-premise (skupper)'],
  ['From cloud to', 1266.72],
]
httpOptionsOnPremise = {
  title: 'From On-Premise cluster',
  bar: {
    groupWidth: '100%'
  },
  legend: {
    position: 'bottom',
    textStyle: {
        fontSize: 14,
    }
  }
}
httpOptionsCloud = {
  title: 'From Cloud cluster',
  bar: {
    groupWidth: '100%'
  },
  legend: {
    position: 'bottom',
    textStyle: {
        fontSize: 14,
    }
  }
}
