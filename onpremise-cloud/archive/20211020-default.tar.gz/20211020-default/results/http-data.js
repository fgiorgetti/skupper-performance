httpDataOnPremise = [
  ['HTTP throughput (requests/s)', 'onprem (skupper)', 'cloud (k8s lb)', 'cloud (route)', 'cloud (skupper)'],
  ['on-premise', 2823.16, 1243.89, 1222.34, 1287.7],
]
httpDataCloud = [
  ['HTTP throughput (requests/s)', 'on-premise (skupper)', 'cloud (skupper)'],
  ['cloud', 1266.72, 2261.98],
]
httpOptionsOnPremise = {
  title: 'From On-Premise cluster',
  bar: {
    groupWidth: '100%'
  },
  legend: {
    position: 'bottom',
    textStyle: {
        fontSize: 14,
    }
  }
}
httpOptionsCloud = {
  title: 'From Cloud cluster',
  bar: {
    groupWidth: '100%'
  },
  legend: {
    position: 'bottom',
    textStyle: {
        fontSize: 14,
    }
  }
}
