postgresData = [
  ['POSTGRES throughput (tps)', 'pod ip', 'load balancer', 'on-premise (skupper)', 'cloud (load balancer)', 'cloud (route)', 'cloud (skupper)'],
  ['on-premise', 424.04, 390.889, 232.543, 3.78273, 0, 3.87512],
  ['cloud', 339.784, 334.688, 3.82444, 334.688, 0, 199.439],
]

postgresOptions = {
  title: 'Skupper - POSTGRES performance numbers',
  bar: {
    groupWidth: '100%'
  },
  chart: {
    title: 'Skupper - POSTGRES performance numbers',
    subtitle: 'On-premise / Cloud (TCP adaptor)',
  }
}
