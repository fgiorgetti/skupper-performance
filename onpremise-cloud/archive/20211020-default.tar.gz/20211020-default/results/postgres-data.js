postgresDataOnPremise = [
  ['POSTGRES throughput (tps)', 'cloud (k8s lb)', 'cloud (route)', 'cloud (skupper)'],
  ['From on-premise to', 3.78273, 0, 3.87512],
]
postgresDataCloud = [
  ['POSTGRES throughput (tps)', 'on-premise (skupper)'],
  ['From cloud to', 3.82444],
]
postgresOptionsOnPremise = {
  title: 'From On-Premise cluster',
  bar: {
    groupWidth: '100%'
  },
  legend: {
    position: 'bottom',
    textStyle: {
        fontSize: 14,
    }
  }
}
postgresOptionsCloud = {
  title: 'From Cloud cluster',
  bar: {
    groupWidth: '100%'
  },
  legend: {
    position: 'bottom',
    textStyle: {
        fontSize: 14,
    }
  }
}
