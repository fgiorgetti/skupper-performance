iperfDataOnPremise = [
  ['IPERF throughput (gbps)', 'on-premise (skupper)', 'cloud (k8s lb)', 'cloud (route)', 'cloud (skupper)'],
  ['on-premise', 2.55, 0.05, 0, 0.03],
]
iperfDataCloud = [
  ['IPERF throughput (gbps)', 'on-premise (skupper)', 'cloud (skupper)'],
  ['cloud', 0.04, 2.69],
]
iperfOptionsOnPremise = {
  title: 'From On-Premise cluster',
  bar: {
    groupWidth: '100%'
  },
  legend: {
    position: 'bottom',
    textStyle: {
        fontSize: 14,
    }
  }
}
iperfOptionsCloud = {
  title: 'From Cloud cluster',
  bar: {
    groupWidth: '100%'
  },
  legend: {
    position: 'bottom',
    textStyle: {
        fontSize: 14,
    }
  }
}

iperfData = [
  ['IPERF throughput (gbps)', 'pod ip', 'load balancer', 'on-premise (skupper)', 'cloud (load balancer)', 'cloud (route)', 'cloud (skupper)'],
  ['on-premise', 7.07, 23.2, 2.55, 0.05, 0, 0.03],
  ['cloud', 24.6, 23.2, 0.04, 23.2, 0, 2.69],
]

iperfOptions = {
  title: 'Skupper - IPERF performance numbers',
  bar: {
    groupWidth: '100%'
  },
  chart: {
    title: 'Skupper - IPERF performance numbers',
    subtitle: 'On-premise / Cloud (TCP adaptor)'
  }
}
