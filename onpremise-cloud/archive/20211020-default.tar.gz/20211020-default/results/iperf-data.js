iperfDataOnPremise = [
  ['IPERF throughput (gbps)', 'cloud (k8s lb)', 'cloud (route)', 'cloud (skupper)'],
  ['From on-premise to', 0.05, 0, 0.03],
]
iperfDataCloud = [
  ['IPERF throughput (gbps)', 'on-premise (skupper)'],
  ['From cloud to', 0.04],
]
iperfOptionsOnPremise = {
  title: 'From On-Premise cluster',
  bar: {
    groupWidth: '100%'
  },
  legend: {
    position: 'bottom',
    textStyle: {
        fontSize: 14,
    }
  }
}
iperfOptionsCloud = {
  title: 'From Cloud cluster',
  bar: {
    groupWidth: '100%'
  },
  legend: {
    position: 'bottom',
    textStyle: {
        fontSize: 14,
    }
  }
}
