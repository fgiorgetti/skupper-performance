httpDataOnPremise = [
  ['HTTP throughput (requests/s)', 'cloud (k8s lb)', 'cloud (route)', 'cloud (skupper)'],
  ['on-premise', 0, 15233.4, 128.265],
]
httpDataCloud = [
  ['HTTP throughput (requests/s)', 'on-premise (skupper)'],
  ['cloud', 204.537],
]
httpOptionsOnPremise = {
  title: 'From On-Premise cluster',
  bar: {
    groupWidth: '100%'
  },
  legend: {
    position: 'bottom',
    textStyle: {
        fontSize: 14,
    }
  }
}
httpOptionsCloud = {
  title: 'From Cloud cluster',
  bar: {
    groupWidth: '100%'
  },
  legend: {
    position: 'bottom',
    textStyle: {
        fontSize: 14,
    }
  }
}

httpDataFull = [
  ['HTTP throughput (requests/s)', 'pod ip', 'load balancer', 'on-premise (skupper)', 'cloud (load balancer)', 'cloud (route)', 'cloud (skupper)'],
  ['on-premise', 35066.7, 32635.4, 2889.47, 0, 15233.4, 128.265],
  ['cloud', 35118.1, 32133.8, 352.185, 32133.8, 20178.4, 204.537],
]

httpOptionsFull = {
  title: 'Skupper - HTTP performance numbers (requests/s) - HTTP',
  bar: {
    groupWidth: '100%'
  },
  chart: {
    title: 'Skupper - HTTP performance numbers',
    subtitle: 'On-premise / Cloud (HTTP adaptor)',
  }
}
