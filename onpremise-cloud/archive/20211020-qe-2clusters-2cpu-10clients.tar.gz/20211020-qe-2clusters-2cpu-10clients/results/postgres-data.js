postgresData = [
  ['POSTGRES throughput (tps)', 'pod ip', 'load balancer', 'on-premise (skupper)', 'cloud (load balancer)', 'cloud (route)', 'cloud (skupper)'],
  ['on-premise', 928.875, 869.363, 497.984, 0, 0, 24.9616],
  ['cloud', 1301.39, 1338.54, 40.892, 1338.54, 0, 33.322],
]

postgresOptions = {
  title: 'Skupper - POSTGRES performance numbers (tps) - TCP',
  bar: {
    groupWidth: '100%'
  },
  chart: {
    title: 'Skupper - POSTGRES performance numbers',
    subtitle: 'On-premise / Cloud (TCP adaptor)',
  }
}
