iperfDataOnPremise = [
  ['IPERF throughput (gbps)', 'cloud (k8s lb)', 'cloud (route)', 'cloud (skupper)'],
  ['on-premise', 0, 0, 0.19],
]
iperfDataCloud = [
  ['IPERF throughput (gbps)', 'on-premise (skupper)'],
  ['cloud', 0.35],
]
iperfOptionsOnPremise = {
  title: 'From On-Premise cluster',
  bar: {
    groupWidth: '100%'
  },
  legend: {
    position: 'bottom',
    textStyle: {
        fontSize: 14,
    }
  }
}
iperfOptionsCloud = {
  title: 'From Cloud cluster',
  bar: {
    groupWidth: '100%'
  },
  legend: {
    position: 'bottom',
    textStyle: {
        fontSize: 14,
    }
  }
}

iperfData = [
  ['IPERF throughput (gbps)', 'pod ip', 'load balancer', 'on-premise (skupper)', 'cloud (load balancer)', 'cloud (route)', 'cloud (skupper)'],
  ['on-premise', 2.76, 2.84, 2.76, 0, 0, 0.19],
  ['cloud', 28.1, 20.6, 0.11, 20.6, 0, 0.35],
]

iperfOptions = {
  title: 'Skupper - IPERF performance numbers (gbps) - TCP',
  bar: {
    groupWidth: '100%'
  },
  chart: {
    title: 'Skupper - IPERF performance numbers',
    subtitle: 'On-premise / Cloud (TCP adaptor)',
  }
}
