httpDataOnPremise = [
  ['HTTP throughput (requests/s)', 'onprem (skupper)', 'cloud (k8s lb)', 'cloud (route)', 'cloud (skupper)'],
  ['on-premise', 2262.37, 264.728, 258.448, 240.998],
]
httpDataCloud = [
  ['HTTP throughput (requests/s)', 'on-premise (skupper)', 'cloud (skupper)'],
  ['cloud', 262.928, 1998.41],
]
httpOptionsOnPremise = {
  title: 'From On-Premise cluster',
  bar: {
    groupWidth: '100%'
  },
  legend: {
    position: 'bottom',
    textStyle: {
        fontSize: 14,
    }
  }
}
httpOptionsCloud = {
  title: 'From Cloud cluster',
  bar: {
    groupWidth: '100%'
  },
  legend: {
    position: 'bottom',
    textStyle: {
        fontSize: 14,
    }
  }
}

httpDataFull = [
  ['HTTP throughput (requests/s)', 'pod ip', 'load balancer', 'on-premise (skupper)', 'cloud (load balancer)', 'cloud (route)', 'cloud (skupper)'],
  ['on-premise', 12595.7, 11344.4, 2262.37, 264.728, 258.448, 240.998],
  ['cloud', 12660.7, 13377.8, 262.928, 13377.8, 4918.16, 1998.41],
]

httpOptionsFull = {
  title: 'Skupper - HTTP performance numbers (requests/s) - HTTP',
  bar: {
    groupWidth: '100%'
  },
  chart: {
    title: 'Skupper - HTTP performance numbers',
    subtitle: 'On-premise / Cloud (HTTP adaptor)',
  }
}
