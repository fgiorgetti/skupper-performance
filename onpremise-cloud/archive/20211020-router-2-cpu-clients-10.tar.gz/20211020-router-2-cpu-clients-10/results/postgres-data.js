postgresData = [
  ['POSTGRES throughput (tps)', 'pod ip', 'load balancer', 'on-premise (skupper)', 'cloud (load balancer)', 'cloud (route)', 'cloud (skupper)'],
  ['on-premise', 1444.04, 1553.37, 486.746, 13.3183, 0, 13.1922],
  ['cloud', 625.699, 642.564, 0, 642.564, 0, 380.48],
]

postgresOptions = {
  title: 'Skupper - POSTGRES performance numbers (tps) - TCP',
  bar: {
    groupWidth: '100%'
  },
  chart: {
    title: 'Skupper - POSTGRES performance numbers',
    subtitle: 'On-premise / Cloud (TCP adaptor)',
  }
}
