iperfData = [
  ['IPERF throughput (gbps)', 'pod ip', 'load balancer', 'on-premise (skupper)', 'cloud (load balancer)', 'cloud (route)', 'cloud (skupper)'],
  ['on-premise', 6.63, 8.1, 3.85, 0.07, 0, 0.04],
  ['cloud', 21, 23, 0.09, 23, 0, 0.74],
]

iperfOptions = {
  title: 'Skupper - IPERF performance numbers (gbps) - TCP',
  bar: {
    groupWidth: '100%'
  },
  chart: {
    title: 'Skupper - IPERF performance numbers',
    subtitle: 'On-premise / Cloud (TCP adaptor)',
  }
}
