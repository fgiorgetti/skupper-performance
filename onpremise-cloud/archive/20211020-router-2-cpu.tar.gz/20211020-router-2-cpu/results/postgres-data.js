postgresDataOnPremise = [
  ['POSTGRES throughput (tps)', 'onprem (skupper)', 'cloud (k8s lb)', 'cloud (route)', 'cloud (skupper)'],
  ['on-premise', 163.889, 3.6121, 0, 3.83989],
]
postgresDataCloud = [
  ['POSTGRES throughput (tps)', 'on-premise (skupper)', 'cloud (skupper)'],
  ['cloud', 3.85405, 156.662],
]
postgresOptionsOnPremise = {
  title: 'From On-Premise cluster',
  bar: {
    groupWidth: '100%'
  },
  legend: {
    position: 'bottom',
    textStyle: {
        fontSize: 14,
    }
  }
}
postgresOptionsCloud = {
  title: 'From Cloud cluster',
  bar: {
    groupWidth: '100%'
  },
  legend: {
    position: 'bottom',
    textStyle: {
        fontSize: 14,
    }
  }
}

postgresData = [
  ['POSTGRES throughput (tps)', 'pod ip', 'load balancer', 'on-premise (skupper)', 'cloud (load balancer)', 'cloud (route)', 'cloud (skupper)'],
  ['on-premise', 892.986, 902.24, 163.889, 3.6121, 0, 3.83989],
  ['cloud', 322.637, 326.682, 3.85405, 326.682, 0, 156.662],
]

postgresOptions = {
  title: 'Skupper - POSTGRES performance numbers (tps) - TCP',
  bar: {
    groupWidth: '100%'
  },
  chart: {
    title: 'Skupper - POSTGRES performance numbers',
    subtitle: 'On-premise / Cloud (TCP adaptor)',
  }
}
