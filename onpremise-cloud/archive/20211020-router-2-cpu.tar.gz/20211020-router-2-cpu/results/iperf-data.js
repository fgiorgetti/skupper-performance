iperfData = [
  ['IPERF throughput (gbps)', 'pod ip', 'load balancer', 'on-premise (skupper)', 'cloud (load balancer)', 'cloud (route)', 'cloud (skupper)'],
  ['on-premise', 4.6, 5.29, 2.13, 0.04, 0, 0.03],
  ['cloud', 24.4, 22.6, 0.07, 22.6, 0, 0.68],
]

iperfOptions = {
  title: 'Skupper - IPERF performance numbers (gbps) - TCP',
  bar: {
    groupWidth: '100%'
  },
  chart: {
    title: 'Skupper - IPERF performance numbers',
    subtitle: 'On-premise / Cloud (TCP adaptor)',
  }
}
