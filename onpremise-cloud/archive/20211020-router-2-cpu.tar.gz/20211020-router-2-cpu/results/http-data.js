httpDataOnPremise = [
  ['HTTP throughput (requests/s)', 'cloud (k8s lb)', 'cloud (route)', 'cloud (skupper)'],
  ['on-premise', 1236.02, 1157.59, 1210.38],
]
httpDataCloud = [
  ['HTTP throughput (requests/s)', 'on-premise (skupper)'],
  ['cloud', 1240.01],
]
httpOptionsOnPremise = {
  title: 'From On-Premise cluster',
  bar: {
    groupWidth: '100%'
  },
  legend: {
    position: 'bottom',
    textStyle: {
        fontSize: 14,
    }
  }
}
httpOptionsCloud = {
  title: 'From Cloud cluster',
  bar: {
    groupWidth: '100%'
  },
  legend: {
    position: 'bottom',
    textStyle: {
        fontSize: 14,
    }
  }
}

httpData = [
  ['HTTP throughput (requests/s)', 'pod ip', 'load balancer', 'on-premise (skupper)', 'cloud (load balancer)', 'cloud (route)', 'cloud (skupper)'],
  ['on-premise', 41081.8, 25135.3, 2193.07, 1236.02, 1157.59, 1210.38],
  ['cloud', 15612.2, 15848.9, 1240.01, 15848.9, 7187.93, 2076.47],
]

httpOptions = {
  title: 'Skupper - HTTP performance numbers (requests/s) - HTTP',
  bar: {
    groupWidth: '100%'
  },
  chart: {
    title: 'Skupper - HTTP performance numbers',
    subtitle: 'On-premise / Cloud (HTTP adaptor)',
  }
}
